# ctr-rsh
cutting edge AI based model dedicated for crt refrenced study
